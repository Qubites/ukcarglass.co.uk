import React from "react";
import { Navbar11 } from "./components/Navbar11";
import { Header47 } from "./components/Header47";
import { Layout13 } from "./components/Layout13";
import { Layout370 } from "./components/Layout370";
import { Layout220 } from "./components/Layout220";
import { Team3 } from "./components/Team3";
import { Testimonial17 } from "./components/Testimonial17";

export default function Page() {
  return (
    <div>
      <Navbar11 />
      <Header47 />
      <Layout13 />
      <Layout370 />
      <Layout220 />
      <Team3 />
      <Testimonial17 />
    </div>
  );
}

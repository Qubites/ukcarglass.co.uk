import React from "react";
import { Navbar11 } from "./components/Navbar11";
import { Header47 } from "./components/Header47";
import { Testimonial17 } from "./components/Testimonial17";
import { Layout395 } from "./components/Layout395";
import { Cta1 } from "./components/Cta1";
import { Faq5 } from "./components/Faq5";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar11 />
      <Header47 />
      <Testimonial17 />
      <Layout395 />
      <Cta1 />
      <Faq5 />
      <Footer1 />
    </div>
  );
}

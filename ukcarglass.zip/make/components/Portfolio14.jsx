"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";
import { RxChevronRight } from "react-icons/rx";

export function Portfolio14() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="mx-auto mb-12 max-w-lg text-center md:mb-18 lg:mb-20">
          <p className="mb-3 font-semibold md:mb-4">Models</p>
          <h2 className="mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
            Popular {make} models
          </h2>
          <p className="md:text-md">
            Browse common {make} models and get a price for your glass.
          </p>
        </div>
        <div className="columns-1 after:block md:columns-2 md:gap-x-8 lg:columns-3">
          <article className="mb-8 break-inside-avoid border border-border-primary">
            <div>
              <a href="#">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  className="w-full object-cover"
                  alt="Relume placeholder image"
                />
              </a>
            </div>
            <div className="px-5 py-6 sm:px-6">
              <h3 className="mb-2 text-xl font-bold md:text-2xl">
                <a href="#">{make} model one</a>
              </h3>
              <p>Windscreen, rear and side glass available.</p>
              <ul className="mt-3 flex flex-wrap gap-2 md:mt-4">
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Windscreen
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Mobile fitting
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    ADAS ready
                  </a>
                </li>
              </ul>
              <Button
                title="View"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
                asChild={true}
                className="mt-5 md:mt-6"
              >
                <a href="#">View</a>
              </Button>
            </div>
          </article>
          <article className="mb-8 break-inside-avoid border border-border-primary">
            <div>
              <a href="#">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  className="w-full object-cover"
                  alt="Relume placeholder image"
                />
              </a>
            </div>
            <div className="px-5 py-6 sm:px-6">
              <h3 className="mb-2 text-xl font-bold md:text-2xl">
                <a href="#">{make} model two</a>
              </h3>
              <p>Windscreen, rear and side glass available.</p>
              <ul className="mt-3 flex flex-wrap gap-2 md:mt-4">
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Windscreen
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Mobile fitting
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    ADAS ready
                  </a>
                </li>
              </ul>
              <Button
                title="View"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
                asChild={true}
                className="mt-5 md:mt-6"
              >
                <a href="#">View</a>
              </Button>
            </div>
          </article>
          <article className="mb-8 break-inside-avoid border border-border-primary">
            <div>
              <a href="#">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                  className="w-full object-cover"
                  alt="Relume placeholder image"
                />
              </a>
            </div>
            <div className="px-5 py-6 sm:px-6">
              <h3 className="mb-2 text-xl font-bold md:text-2xl">
                <a href="#">{make} model three</a>
              </h3>
              <p>Windscreen, rear and side glass available.</p>
              <ul className="mt-3 flex flex-wrap gap-2 md:mt-4">
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Windscreen
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Mobile fitting
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    ADAS ready
                  </a>
                </li>
              </ul>
              <Button
                title="View"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
                asChild={true}
                className="mt-5 md:mt-6"
              >
                <a href="#">View</a>
              </Button>
            </div>
          </article>
          <article className="mb-8 break-inside-avoid border border-border-primary">
            <div>
              <a href="#">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  className="w-full object-cover"
                  alt="Relume placeholder image"
                />
              </a>
            </div>
            <div className="px-5 py-6 sm:px-6">
              <h3 className="mb-2 text-xl font-bold md:text-2xl">
                <a href="#">{make} model four</a>
              </h3>
              <p>Windscreen, rear and side glass available.</p>
              <ul className="mt-3 flex flex-wrap gap-2 md:mt-4">
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Windscreen
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Mobile fitting
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    ADAS ready
                  </a>
                </li>
              </ul>
              <Button
                title="View"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
                asChild={true}
                className="mt-5 md:mt-6"
              >
                <a href="#">View</a>
              </Button>
            </div>
          </article>
          <article className="mb-8 break-inside-avoid border border-border-primary">
            <div>
              <a href="#">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  className="w-full object-cover"
                  alt="Relume placeholder image"
                />
              </a>
            </div>
            <div className="px-5 py-6 sm:px-6">
              <h3 className="mb-2 text-xl font-bold md:text-2xl">
                <a href="#">{make} model five</a>
              </h3>
              <p>Windscreen, rear and side glass available.</p>
              <ul className="mt-3 flex flex-wrap gap-2 md:mt-4">
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Windscreen
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Mobile fitting
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    ADAS ready
                  </a>
                </li>
              </ul>
              <Button
                title="View"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
                asChild={true}
                className="mt-5 md:mt-6"
              >
                <a href="#">View</a>
              </Button>
            </div>
          </article>
          <article className="mb-8 break-inside-avoid border border-border-primary">
            <div>
              <a href="#">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  className="w-full object-cover"
                  alt="Relume placeholder image"
                />
              </a>
            </div>
            <div className="px-5 py-6 sm:px-6">
              <h3 className="mb-2 text-xl font-bold md:text-2xl">
                <a href="#">{make} model six</a>
              </h3>
              <p>Windscreen, rear and side glass available.</p>
              <ul className="mt-3 flex flex-wrap gap-2 md:mt-4">
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Windscreen
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    Mobile fitting
                  </a>
                </li>
                <li className="flex">
                  <a
                    href="#"
                    className="bg-background-secondary px-2 py-1 text-sm font-semibold"
                  >
                    ADAS ready
                  </a>
                </li>
              </ul>
              <Button
                title="View"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
                asChild={true}
                className="mt-5 md:mt-6"
              >
                <a href="#">View</a>
              </Button>
            </div>
          </article>
        </div>
        <div className="mt-8 flex justify-center md:mt-18 lg:mt-20">
          <Button title="All models" variant="secondary" size="primary">
            All models
          </Button>
        </div>
      </div>
    </section>
  );
}

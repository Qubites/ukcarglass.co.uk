import React from "react";
import { Navbar11 } from "./components/Navbar11";
import { Header47 } from "./components/Header47";
import { Layout369 } from "./components/Layout369";
import { Layout239 } from "./components/Layout239";
import { Portfolio14 } from "./components/Portfolio14";
import { Layout369_1 } from "./components/Layout369_1";
import { Cta1 } from "./components/Cta1";
import { Faq5 } from "./components/Faq5";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar11 />
      <Header47 />
      <Layout369 />
      <Layout239 />
      <Portfolio14 />
      <Layout369_1 />
      <Cta1 />
      <Faq5 />
      <Footer1 />
    </div>
  );
}

import React from "react";
import { Navbar11 } from "./components/Navbar11";
import { Header47 } from "./components/Header47";
import { Timeline17 } from "./components/Timeline17";
import { Layout145 } from "./components/Layout145";
import { Layout145_1 } from "./components/Layout145_1";
import { Layout145_2 } from "./components/Layout145_2";
import { Layout149 } from "./components/Layout149";
import { Layout363 } from "./components/Layout363";
import { Layout145_3 } from "./components/Layout145_3";
import { Layout141 } from "./components/Layout141";
import { Layout149_1 } from "./components/Layout149_1";
import { Cta1 } from "./components/Cta1";
import { Faq5 } from "./components/Faq5";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar11 />
      <Header47 />
      <Timeline17 />
      <Layout145 />
      <Layout145_1 />
      <Layout145_2 />
      <Layout149 />
      <Layout363 />
      <Layout145_3 />
      <Layout141 />
      <Layout149_1 />
      <Cta1 />
      <Faq5 />
      <Footer1 />
    </div>
  );
}

"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";
import { RxChevronRight } from "react-icons/rx";

export function Layout363() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="rb-12 mb-12 md:mb-18 lg:mb-20">
          <div className="mx-auto max-w-lg text-center">
            <p className="mb-3 font-semibold md:mb-4">ADAS</p>
            <h2 className="rb-5 mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
              Calibration needed
            </h2>
            <p className="md:text-md">
              Some vehicles require camera alignment after glass replacement.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 items-start gap-6 md:gap-8 lg:grid-cols-2">
          <div className="grid grid-cols-1 items-start border border-border-primary sm:grid-cols-2">
            <div className="flex size-full items-center justify-center">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                className="size-full object-cover"
                alt="Relume placeholder image 1"
              />
            </div>
            <div className="flex h-full flex-col justify-center p-6">
              <p className="mb-2 text-sm font-semibold">Yes</p>
              <h3 className="mb-2 text-xl font-bold md:text-2xl">
                What is ADAS calibration
              </h3>
              <p>
                Modern vehicles use cameras and sensors behind the windscreen.
                Replacement glass needs realignment to keep safety systems
                working properly.
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-4 md:mt-6">
                <Button
                  title="Learn more"
                  variant="link"
                  size="link"
                  iconRight={<RxChevronRight />}
                >
                  Learn more
                </Button>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 items-start border border-border-primary sm:grid-cols-2">
            <div className="flex size-full items-center justify-center">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                className="size-full object-cover"
                alt="Relume placeholder image 1"
              />
            </div>
            <div className="flex h-full flex-col justify-center p-6">
              <p className="mb-2 text-sm font-semibold">No</p>
              <h3 className="mb-2 text-xl font-bold md:text-2xl">
                My vehicle doesn't need it
              </h3>
              <p>
                We'll confirm this based on your vehicle details. If you're
                unsure, our team can advise.
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-4 md:mt-6">
                <Button
                  title="Ask us"
                  variant="link"
                  size="link"
                  iconRight={<RxChevronRight />}
                >
                  Ask us
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

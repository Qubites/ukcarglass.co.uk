import React from "react";
import { Navbar11 } from "./components/Navbar11";
import { Header26 } from "./components/Header26";
import { Layout520 } from "./components/Layout520";
import { Testimonial17 } from "./components/Testimonial17";
import { Cta1 } from "./components/Cta1";
import { Faq5 } from "./components/Faq5";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar11 />
      <Header26 />
      <Layout520 />
      <Testimonial17 />
      <Cta1 />
      <Faq5 />
      <Footer1 />
    </div>
  );
}

import React from "react";
import { Navbar11 } from "./components/Navbar11";
import { Header47 } from "./components/Header47";

export default function Page() {
  return (
    <div>
      <Navbar11 />
      <Header47 />
    </div>
  );
}

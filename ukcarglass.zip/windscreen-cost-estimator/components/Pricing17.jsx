"use client";

import {
  Button,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@relume_io/relume-ui";
import React from "react";
import { BiCheck } from "react-icons/bi";

export function Pricing17() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="mx-auto mb-8 max-w-lg text-center md:mb-10 lg:mb-12">
          <p className="mb-3 font-semibold md:mb-4">Estimate</p>
          <h2 className="rb-5 mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
            Your exact price
          </h2>
          <p className="md:text-md">
            Most windscreens fall between £150 and £400 depending on your
            vehicle and glass type.
          </p>
        </div>
        <Tabs defaultValue="monthly">
          <TabsList className="mx-auto mb-12 w-fit">
            <TabsTrigger value="monthly">Windscreen</TabsTrigger>
            <TabsTrigger value="yearly">Rear</TabsTrigger>
          </TabsList>
          <TabsContent
            value="monthly"
            className="grid grid-cols-1 gap-8 data-[state=active]:animate-tabs md:grid-cols-2"
          >
            <div className="flex h-full flex-col justify-between border border-border-primary px-6 py-8 md:p-8">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="rb-4 mb-4 flex flex-col items-start justify-end">
                      <img
                        src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                        alt="Relume icon 1"
                        className="size-12"
                      />
                    </div>
                    <h5 className="mb-2 text-xl font-bold md:text-2xl">
                      Windscreen replacement
                    </h5>
                    <p>From £150</p>
                  </div>
                  <div className="text-right">
                    <h1 className="text-6xl font-bold md:text-9xl lg:text-10xl">
                      £150–£280
                    </h1>
                  </div>
                </div>
                <div className="my-8 h-px w-full shrink-0 bg-border" />
                <p>Includes</p>
                <div className="mb-8 mt-4 grid grid-cols-1 gap-x-6 gap-y-4 py-2 lg:grid-cols-2">
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>OEM or equivalent glass</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Mobile fitting at your address</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>12-month warranty</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Debris removal and cleanup</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>VAT and labour included</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>No hidden charges</p>
                  </div>
                </div>
              </div>
              <div>
                <Button title="Get price and book" className="w-full">
                  Get price and book
                </Button>
              </div>
            </div>
            <div className="flex h-full flex-col justify-between border border-border-primary px-6 py-8 md:p-8">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="rb-4 mb-4 flex flex-col items-start justify-end">
                      <img
                        src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                        alt="Relume icon 1"
                        className="size-12"
                      />
                    </div>
                    <h5 className="mb-2 text-xl font-bold md:text-2xl">
                      Rear window replacement
                    </h5>
                    <p>From £120</p>
                  </div>
                  <div className="text-right">
                    <h1 className="text-6xl font-bold md:text-9xl lg:text-10xl">
                      £120–£240
                    </h1>
                  </div>
                </div>
                <div className="my-8 h-px w-full shrink-0 bg-border" />
                <p>Includes</p>
                <div className="mb-8 mt-4 grid grid-cols-1 gap-x-6 gap-y-4 py-2 lg:grid-cols-2">
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>OEM or equivalent glass</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Mobile fitting at your address</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>12-month warranty</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Debris removal and cleanup</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>VAT and labour included</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>No hidden charges</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Heated rear window support</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Acoustic glass available</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Tinted options on request</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Insurance billing available</p>
                  </div>
                </div>
              </div>
              <div>
                <Button title="Get price and book" className="w-full">
                  Get price and book
                </Button>
              </div>
            </div>
          </TabsContent>
          <TabsContent
            value="yearly"
            className="grid grid-cols-1 gap-8 data-[state=active]:animate-tabs md:grid-cols-2"
          >
            <div className="flex h-full flex-col justify-between border border-border-primary px-6 py-8 md:p-8">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="rb-4 mb-4 flex flex-col items-start justify-end">
                      <img
                        src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                        alt="Relume icon 1"
                        className="size-12"
                      />
                    </div>
                    <h5 className="mb-2 text-xl font-bold md:text-2xl">
                      Side window replacement
                    </h5>
                    <p>From £100</p>
                  </div>
                  <div className="text-right">
                    <h1 className="text-6xl font-bold md:text-9xl lg:text-10xl">
                      £100–£200
                    </h1>
                    <p className="mt-2 font-medium">Varies by vehicle</p>
                  </div>
                </div>
                <div className="my-8 h-px w-full shrink-0 bg-border" />
                <p>Includes</p>
                <div className="mb-8 mt-4 grid grid-cols-1 gap-x-6 gap-y-4 py-2 lg:grid-cols-2">
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>OEM or equivalent glass</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Mobile fitting at your address</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>12-month warranty</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Debris removal and cleanup</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>VAT and labour included</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>No hidden charges</p>
                  </div>
                </div>
              </div>
              <div>
                <Button title="Get price and book" className="w-full">
                  Get price and book
                </Button>
              </div>
            </div>
            <div className="flex h-full flex-col justify-between border border-border-primary px-6 py-8 md:p-8">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="rb-4 mb-4 flex flex-col items-start justify-end">
                      <img
                        src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                        alt="Relume icon 1"
                        className="size-12"
                      />
                    </div>
                    <h5 className="mb-2 text-xl font-bold md:text-2xl">
                      ADAS-equipped windscreen
                    </h5>
                    <p>From £280</p>
                  </div>
                  <div className="text-right">
                    <h1 className="text-6xl font-bold md:text-9xl lg:text-10xl">
                      £280–£450
                    </h1>
                    <p className="mt-2 font-medium">Includes calibration</p>
                  </div>
                </div>
                <div className="my-8 h-px w-full shrink-0 bg-border" />
                <p>Includes</p>
                <div className="mb-8 mt-4 grid grid-cols-1 gap-x-6 gap-y-4 py-2 lg:grid-cols-2">
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>OEM or equivalent glass</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Mobile fitting at your address</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>ADAS calibration included</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>12-month warranty</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Debris removal and cleanup</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>VAT and labour included</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Specialist equipment used</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>No hidden charges</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Insurance billing available</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Warranty covers recalibration</p>
                  </div>
                </div>
              </div>
              <div>
                <Button title="Get price and book" className="w-full">
                  Get price and book
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}

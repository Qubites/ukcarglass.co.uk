import React from "react";
import { Navbar11 } from "./components/Navbar11";
import { Header47 } from "./components/Header47";
import { Layout245 } from "./components/Layout245";
import { Pricing17 } from "./components/Pricing17";
import { Cta1 } from "./components/Cta1";
import { Faq5 } from "./components/Faq5";
import { Testimonial17 } from "./components/Testimonial17";
import { Cta1_1 } from "./components/Cta1_1";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar11 />
      <Header47 />
      <Layout245 />
      <Pricing17 />
      <Cta1 />
      <Faq5 />
      <Testimonial17 />
      <Cta1_1 />
      <Footer1 />
    </div>
  );
}

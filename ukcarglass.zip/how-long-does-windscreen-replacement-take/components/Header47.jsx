"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";

export function Header47() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="flex flex-col gap-5 md:flex-row md:gap-12 lg:gap-20">
          <div className="w-full max-w-lg">
            <p className="mb-3 font-semibold md:mb-4">Guide</p>
            <h1 className="text-6xl font-bold md:text-9xl lg:text-10xl">
              Windscreen replacement time
            </h1>
          </div>
          <div className="w-full max-w-lg">
            <p className="md:text-md">
              Most replacements take 30 to 60 minutes from start to finish. Our
              mobile technicians arrive at your location with everything needed,
              so there's no waiting around at a garage.
            </p>
            <div className="mt-6 flex flex-wrap gap-4 md:mt-8">
              <Button title="Book">Book</Button>
              <Button title="Estimate" variant="secondary">
                Estimate
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

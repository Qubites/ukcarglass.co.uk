import React from "react";
import { Navbar11 } from "./components/Navbar11";
import { Header47 } from "./components/Header47";
import { Layout388 } from "./components/Layout388";
import { Layout492 } from "./components/Layout492";
import { Layout494 } from "./components/Layout494";
import { Faq5 } from "./components/Faq5";

export default function Page() {
  return (
    <div>
      <Navbar11 />
      <Header47 />
      <Layout388 />
      <Layout492 />
      <Layout494 />
      <Faq5 />
    </div>
  );
}

"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";
import { RxChevronRight } from "react-icons/rx";

export function Layout19() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="grid grid-cols-1 gap-y-12 md:grid-cols-2 md:items-center md:gap-x-12 lg:gap-x-20">
          <div>
            <p className="mb-3 font-semibold md:mb-4">Understanding ADAS</p>
            <h2 className="mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
              What is ADAS and why does it matter?
            </h2>
            <p className="mb-5 md:mb-6 md:text-md">
              ADAS stands for Advanced Driver Assistance Systems. These are the
              safety features in your car that help prevent
              accidents—lane-keeping assist, automatic emergency braking,
              adaptive cruise control, and collision warning. Most of these
              systems rely on cameras and sensors mounted behind your
              windscreen. When your windscreen is replaced, these systems need
              to be recalibrated to work correctly.
            </p>
            <ul className="my-4 list-disc pl-5">
              <li className="my-1 self-start pl-2">
                <p>Camera and sensor systems</p>
              </li>
              <li className="my-1 self-start pl-2">
                <p>Precise calibration required</p>
              </li>
              <li className="my-1 self-start pl-2">
                <p>Safety-critical technology</p>
              </li>
            </ul>
            <div className="mt-6 flex flex-wrap items-center gap-4 md:mt-8">
              <Button title="Learn more" variant="secondary">
                Learn more
              </Button>
              <Button
                title="Read our full guide"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
              >
                Read our full guide
              </Button>
            </div>
          </div>
          <div>
            <img
              src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
              className="w-full object-cover"
              alt="Relume placeholder image"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

import React from "react";
import { Navbar11 } from "./components/Navbar11";
import { Header47 } from "./components/Header47";
import { Content29 } from "./components/Content29";
import { Faq5 } from "./components/Faq5";
import { Cta1 } from "./components/Cta1";
import { Header47_1 } from "./components/Header47_1";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar11 />
      <Header47 />
      <Content29 />
      <Faq5 />
      <Cta1 />
      <Header47_1 />
      <Footer1 />
    </div>
  );
}

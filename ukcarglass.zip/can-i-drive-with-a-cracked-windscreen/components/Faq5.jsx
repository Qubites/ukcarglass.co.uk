"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
  Button,
} from "@relume_io/relume-ui";
import React from "react";
import { RxPlus } from "react-icons/rx";

export function Faq5() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="rb-12 mb-12 max-w-lg md:mb-18 lg:mb-20">
          <h2 className="rb-5 mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
            FAQs
          </h2>
          <p className="md:text-md">
            Common questions about driving with a cracked windscreen and what
            you need to know.
          </p>
        </div>
        <Accordion
          type="multiple"
          className="grid items-start justify-stretch gap-4"
        >
          <AccordionItem
            value="item-0"
            className="border border-border-primary px-5 md:px-6"
          >
            <AccordionTrigger
              icon={
                <RxPlus className="size-7 shrink-0 text-text-primary transition-transform duration-300 md:size-8" />
              }
              className="md:py-5 md:text-md [&[data-state=open]>svg]:rotate-45"
            >
              Will I get points on my licence?
            </AccordionTrigger>
            <AccordionContent className="md:pb-6">
              Yes. Driving with a cracked windscreen that obstructs your vision
              is an offence under the Road Vehicles (Construction and Use)
              Regulations. You can receive three penalty points and a fine up to
              £1,000. The damage must be in the driver's line of sight to count.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem
            value="item-1"
            className="border border-border-primary px-5 md:px-6"
          >
            <AccordionTrigger
              icon={
                <RxPlus className="size-7 shrink-0 text-text-primary transition-transform duration-300 md:size-8" />
              }
              className="md:py-5 md:text-md [&[data-state=open]>svg]:rotate-45"
            >
              Does insurance cover cracked windscreen?
            </AccordionTrigger>
            <AccordionContent className="md:pb-6">
              Most comprehensive policies cover windscreen damage with little or
              no excess. Check your policy documents or contact your insurer.
              Many policies offer a free replacement or repair, making it worth
              claiming rather than paying privately.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem
            value="item-2"
            className="border border-border-primary px-5 md:px-6"
          >
            <AccordionTrigger
              icon={
                <RxPlus className="size-7 shrink-0 text-text-primary transition-transform duration-300 md:size-8" />
              }
              className="md:py-5 md:text-md [&[data-state=open]>svg]:rotate-45"
            >
              How soon should I fix it?
            </AccordionTrigger>
            <AccordionContent className="md:pb-6">
              As soon as possible. A cracked windscreen weakens the structural
              integrity of your vehicle and can fail suddenly. Small cracks
              spread quickly, especially in cold weather or on rough roads. Book
              a replacement today to stay safe and legal.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem
            value="item-3"
            className="border border-border-primary px-5 md:px-6"
          >
            <AccordionTrigger
              icon={
                <RxPlus className="size-7 shrink-0 text-text-primary transition-transform duration-300 md:size-8" />
              }
              className="md:py-5 md:text-md [&[data-state=open]>svg]:rotate-45"
            >
              Will my car fail its MOT?
            </AccordionTrigger>
            <AccordionContent className="md:pb-6">
              Yes, if the crack is in the driver's line of sight or larger than
              30mm. Your vehicle will not pass its MOT test until the windscreen
              is repaired or replaced. This applies to any damage that affects
              visibility or structural safety.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem
            value="item-4"
            className="border border-border-primary px-5 md:px-6"
          >
            <AccordionTrigger
              icon={
                <RxPlus className="size-7 shrink-0 text-text-primary transition-transform duration-300 md:size-8" />
              }
              className="md:py-5 md:text-md [&[data-state=open]>svg]:rotate-45"
            >
              What counts as major damage?
            </AccordionTrigger>
            <AccordionContent className="md:pb-6">
              Any crack longer than 30mm, damage in the driver's line of sight,
              or multiple cracks across the glass are considered major. Damage
              near the edges or corners also weakens the frame. When in doubt,
              get it checked by a professional.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
        <div className="mt-12 md:mt-18 lg:mt-20">
          <h4 className="mb-3 text-2xl font-bold md:mb-4 md:text-3xl md:leading-[1.3] lg:text-4xl">
            Still have questions?
          </h4>
          <p className="md:text-md">Get in touch with our team.</p>
          <div className="mt-6 md:mt-8">
            <Button title="Contact" variant="secondary">
              Contact
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

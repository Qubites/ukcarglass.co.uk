"use client";

import {
  Button,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@relume_io/relume-ui";
import React from "react";
import { BiCheck } from "react-icons/bi";

export function Pricing27() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="mx-auto mb-8 max-w-lg text-center md:mb-10 lg:mb-12">
          <p className="mb-3 font-semibold md:mb-4">Compare</p>
          <h1 className="mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
            Insurance or private
          </h1>
          <p className="md:text-md">
            Understand the real difference between claiming on your insurance
            and paying privately. We'll help you choose the right option for
            your situation.
          </p>
        </div>
        <div className="w-full">
          <Tabs defaultValue="monthly">
            <TabsList className="mx-auto mb-12 flex w-fit md:mb-20">
              <TabsTrigger value="monthly">Insurance</TabsTrigger>
              <TabsTrigger value="yearly">Private</TabsTrigger>
            </TabsList>
            <TabsContent value="monthly">
              <div className="grid grid-cols-3 gap-x-4 bg-white md:grid-cols-[1.5fr_1fr_1fr_1fr] md:gap-x-8">
                <div className="hidden md:block" />
                <div className="flex h-full flex-col justify-between text-center">
                  <div>
                    <h2 className="text-md font-bold leading-[1.4] md:text-xl">
                      Insurance
                    </h2>
                    <div className="my-3 md:my-4">
                      <p className="text-2xl font-bold leading-[1.2] sm:text-6xl md:text-9xl lg:text-10xl">
                        Excess + claim
                      </p>
                    </div>
                    <p>You pay your excess, we bill your insurer</p>
                  </div>
                  <div className="mt-6 md:mt-8">
                    <Button
                      title="Get price"
                      className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                    >
                      Get price
                    </Button>
                  </div>
                </div>
                <div className="flex h-full flex-col justify-between text-center">
                  <div>
                    <h2 className="text-md font-bold leading-[1.4] md:text-xl">
                      Private
                    </h2>
                    <div className="my-3 md:my-4">
                      <p className="text-2xl font-bold leading-[1.2] sm:text-6xl md:text-9xl lg:text-10xl">
                        Full price
                      </p>
                    </div>
                    <p>Pay us directly, no paperwork with insurers</p>
                  </div>
                  <div className="mt-6 md:mt-8">
                    <Button
                      title="Get price"
                      className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                    >
                      Get price
                    </Button>
                  </div>
                </div>
                <div className="flex h-full flex-col justify-between text-center">
                  <div>
                    <h2 className="text-md font-bold leading-[1.4] md:text-xl">
                      Comparison
                    </h2>
                    <div className="my-3 md:my-4">
                      <p className="text-2xl font-bold leading-[1.2] sm:text-6xl md:text-9xl lg:text-10xl">
                        Placeholder
                      </p>
                    </div>
                    <p>Placeholder</p>
                  </div>
                  <div className="mt-6 md:mt-8">
                    <Button
                      title="Excess amount"
                      className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                    >
                      Excess amount
                    </Button>
                  </div>
                </div>
              </div>
              <h3 className="mt-8 py-5 text-md font-bold leading-[1.4] md:text-xl">
                You pay this
              </h3>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Nothing
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  Claim process
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  We handle it
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  You arrange it
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Speed of booking
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Same day often
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Same day often
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Warranty coverage
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <h3 className="mt-8 py-5 text-md font-bold leading-[1.4] md:text-xl">
                Full UKCarGlass warranty
              </h3>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Full UKCarGlass warranty
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  No claims impact
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  May affect future premiums
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  No impact
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Paperwork
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  We manage it
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Minimal
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Get price
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <h3 className="mt-8 py-5 text-md font-bold leading-[1.4] md:text-xl">
                Get price
              </h3>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Get price
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  Insurance
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  Excess + claim
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  You pay your excess, we bill your insurer
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Get price
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Private
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Full price
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Pay us directly, no paperwork with insurers
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="rt-8 mt-8 grid grid-cols-3 gap-x-4 bg-white md:grid-cols-[1.5fr_1fr_1fr_1fr] md:gap-x-8">
                <div className="hidden md:block" />
                <Button
                  title="Placeholder"
                  className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                >
                  Placeholder
                </Button>
                <Button
                  title="Placeholder"
                  className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                >
                  Placeholder
                </Button>
                <Button
                  title="Placeholder"
                  className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                >
                  Placeholder
                </Button>
              </div>
            </TabsContent>
            <TabsContent value="yearly">
              <div className="grid grid-cols-3 gap-x-4 bg-white md:grid-cols-[1.5fr_1fr_1fr_1fr] md:gap-x-8">
                <div className="hidden md:block" />
                <div className="flex h-full flex-col justify-between text-center">
                  <div>
                    <h2 className="text-md font-bold leading-[1.4] md:text-xl">
                      Placeholder
                    </h2>
                    <div className="my-3 md:my-4">
                      <p className="text-2xl font-bold leading-[1.2] sm:text-6xl md:text-9xl lg:text-10xl">
                        Excess amount
                      </p>
                      <p className="font-semibold">You pay this</p>
                    </div>
                    <p>Nothing</p>
                  </div>
                  <div className="mt-6 md:mt-8">
                    <Button
                      title="Claim process"
                      className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                    >
                      Claim process
                    </Button>
                  </div>
                </div>
                <div className="flex h-full flex-col justify-between text-center">
                  <div>
                    <h2 className="text-md font-bold leading-[1.4] md:text-xl">
                      We handle it
                    </h2>
                    <div className="my-3 md:my-4">
                      <p className="text-2xl font-bold leading-[1.2] sm:text-6xl md:text-9xl lg:text-10xl">
                        You arrange it
                      </p>
                      <p className="font-semibold">Speed of booking</p>
                    </div>
                    <p>Same day often</p>
                  </div>
                  <div className="mt-6 md:mt-8">
                    <Button
                      title="Same day often"
                      className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                    >
                      Same day often
                    </Button>
                  </div>
                </div>
                <div className="flex h-full flex-col justify-between text-center">
                  <div>
                    <h2 className="text-md font-bold leading-[1.4] md:text-xl">
                      Warranty coverage
                    </h2>
                    <div className="my-3 md:my-4">
                      <p className="text-2xl font-bold leading-[1.2] sm:text-6xl md:text-9xl lg:text-10xl">
                        Full UKCarGlass warranty
                      </p>
                      <p className="font-semibold">Full UKCarGlass warranty</p>
                    </div>
                    <p>No claims impact</p>
                  </div>
                  <div className="mt-6 md:mt-8">
                    <Button
                      title="May affect future premiums"
                      className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                    >
                      May affect future premiums
                    </Button>
                  </div>
                </div>
              </div>
              <h3 className="mt-8 py-5 text-md font-bold leading-[1.4] md:text-xl">
                No impact
              </h3>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Paperwork
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  We manage it
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  Minimal
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  Get price
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Get price
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Get price
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <h3 className="mt-8 py-5 text-md font-bold leading-[1.4] md:text-xl">
                Feature Category
              </h3>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  10
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  25
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  Unlimited
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <h3 className="mt-8 py-5 text-md font-bold leading-[1.4] md:text-xl">
                Feature Category
              </h3>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  10
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  25
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  Unlimited
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="grid grid-cols-3 odd:bg-background-secondary md:grid-cols-[1.5fr_1fr_1fr_1fr]">
                <p className="col-span-3 row-span-1 p-4 md:col-span-1 md:px-6 md:py-4">
                  Feature text goes here
                </p>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6"></div>
                <div className="flex items-center justify-center px-4 py-4 text-center font-semibold md:px-6">
                  <BiCheck className="size-6" />
                </div>
              </div>
              <div className="rt-8 mt-8 grid grid-cols-3 gap-x-4 bg-white md:grid-cols-[1.5fr_1fr_1fr_1fr] md:gap-x-8">
                <div className="hidden md:block" />
                <Button
                  title="Get started"
                  className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                >
                  Get started
                </Button>
                <Button
                  title="Get started"
                  className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                >
                  Get started
                </Button>
                <Button
                  title="Get started"
                  className="w-full whitespace-normal px-3 py-1 sm:px-4 sm:py-3"
                >
                  Get started
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </section>
  );
}

import React from "react";
import { Navbar11 } from "./components/Navbar11";
import { Header47 } from "./components/Header47";
import { Layout32 } from "./components/Layout32";
import { Layout34 } from "./components/Layout34";
import { Layout356 } from "./components/Layout356";
import { Pricing27 } from "./components/Pricing27";
import { Cta1 } from "./components/Cta1";
import { Faq5 } from "./components/Faq5";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar11 />
      <Header47 />
      <Layout32 />
      <Layout34 />
      <Layout356 />
      <Pricing27 />
      <Cta1 />
      <Faq5 />
      <Footer1 />
    </div>
  );
}

import React from "react";
import { Navbar11 } from "./components/Navbar11";
import { Header47 } from "./components/Header47";
import { Layout485 } from "./components/Layout485";
import { Layout494 } from "./components/Layout494";
import { Pricing17 } from "./components/Pricing17";
import { Comparison13 } from "./components/Comparison13";

export default function Page() {
  return (
    <div>
      <Navbar11 />
      <Header47 />
      <Layout485 />
      <Layout494 />
      <Pricing17 />
      <Comparison13 />
    </div>
  );
}

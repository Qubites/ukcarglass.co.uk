"use client";

import React from "react";
import { BiCheck, BiX } from "react-icons/bi";

export function Comparison13() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container max-w-xl">
        <div className="mx-auto mb-12 max-w-lg text-center md:mb-18 lg:mb-20">
          <p className="mb-3 font-semibold md:mb-4">Compare</p>
          <h2 className="rb-5 mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
            Insurance claim or pay yourself
          </h2>
          <p className="md:text-md">Both routes work. Here's what differs.</p>
        </div>
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
          <div className="flex h-full flex-col justify-between border border-border-primary px-6 py-8 md:p-8">
            <div>
              <div className="rb-4 mb-3 flex flex-col items-start justify-end md:mb-4">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                  alt="Relume icon 1"
                  className="size-12"
                />
              </div>
              <h3 className="mb-2 text-md font-bold leading-[1.4] md:text-xl">
                Insurance claim
              </h3>
              <p className="mb-5 md:mb-6">Through your policy</p>
              <div className="grid grid-cols-1">
                <div className="flex justify-between gap-4 border-b border-border-primary py-6 first:border-t">
                  <p>Excess to pay</p>
                  <h6 className="text-md font-bold leading-[1.4] md:text-lg md:leading-[1.4]">
                    £0–£500
                  </h6>
                </div>
                <div className="flex justify-between gap-4 border-b border-border-primary py-6 first:border-t">
                  <p>Waiting time</p>
                  <h6 className="text-md font-bold leading-[1.4] md:text-lg md:leading-[1.4]">
                    3–7 days
                  </h6>
                </div>
                <div className="flex justify-between gap-4 border-b border-border-primary py-6 first:border-t">
                  <p>No claims impact</p>
                  <h6 className="text-md font-bold leading-[1.4] md:text-lg md:leading-[1.4]">
                    Usually covered
                  </h6>
                </div>
                <div className="flex justify-between gap-4 border-b border-border-primary py-6 first:border-t">
                  <p>Approval needed</p>
                  <h6 className="text-md font-bold leading-[1.4] md:text-lg md:leading-[1.4]">
                    Yes, insurer approves
                  </h6>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-1 gap-y-4 py-2 md:mt-8">
                <div className="flex self-start">
                  <div className="mr-4 flex-none self-start">
                    <BiCheck className="size-6" />
                  </div>
                  <p>Paperwork involved</p>
                </div>
                <div className="flex self-start">
                  <div className="mr-4 flex-none self-start">
                    <BiCheck className="size-6" />
                  </div>
                  <p>Forms and evidence</p>
                </div>
                <div className="flex self-start">
                  <div className="mr-4 flex-none self-start">
                    <BiX className="size-6" />
                  </div>
                  <p>Technician choice</p>
                </div>
                <div className="flex self-start">
                  <div className="mr-4 flex-none self-start">
                    <BiX className="size-6" />
                  </div>
                  <p>Limited to network</p>
                </div>
              </div>
            </div>
          </div>
          <div className="flex h-full flex-col justify-between border border-border-primary px-6 py-8 md:p-8">
            <div>
              <div className="rb-4 mb-3 flex flex-col items-start justify-end md:mb-4">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                  alt="Relume icon 1"
                  className="size-12"
                />
              </div>
              <h3 className="mb-2 text-md font-bold leading-[1.4] md:text-xl">
                Private pay
              </h3>
              <p className="mb-5 md:mb-6">Out of pocket</p>
              <div className="grid grid-cols-1">
                <div className="flex justify-between gap-4 border-b border-border-primary py-6 first:border-t">
                  <p>Cost you pay</p>
                  <h6 className="text-md font-bold leading-[1.4] md:text-lg md:leading-[1.4]">
                    £150–£400
                  </h6>
                </div>
                <div className="flex justify-between gap-4 border-b border-border-primary py-6 first:border-t">
                  <p>Waiting time</p>
                  <h6 className="text-md font-bold leading-[1.4] md:text-lg md:leading-[1.4]">
                    Same day or next
                  </h6>
                </div>
                <div className="flex justify-between gap-4 border-b border-border-primary py-6 first:border-t">
                  <p>No claims impact</p>
                  <h6 className="text-md font-bold leading-[1.4] md:text-lg md:leading-[1.4]">
                    None whatsoever
                  </h6>
                </div>
                <div className="flex justify-between gap-4 border-b border-border-primary py-6 first:border-t">
                  <p>Approval needed</p>
                  <h6 className="text-md font-bold leading-[1.4] md:text-lg md:leading-[1.4]">
                    No approval required
                  </h6>
                </div>
              </div>
              <div className="mt-6 grid grid-cols-1 gap-y-4 py-2 md:mt-8">
                <div className="flex self-start">
                  <div className="mr-4 flex-none self-start">
                    <BiCheck className="size-6" />
                  </div>
                  <p>Paperwork involved</p>
                </div>
                <div className="flex self-start">
                  <div className="mr-4 flex-none self-start">
                    <BiCheck className="size-6" />
                  </div>
                  <p>Minimal, just booking</p>
                </div>
                <div className="flex self-start">
                  <div className="mr-4 flex-none self-start">
                    <BiCheck className="size-6" />
                  </div>
                  <p>Technician choice</p>
                </div>
                <div className="flex self-start">
                  <div className="mr-4 flex-none self-start">
                    <BiCheck className="size-6" />
                  </div>
                  <p>You choose us directly</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

"use client";

import {
  Button,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@relume_io/relume-ui";
import React from "react";
import { BiCheck } from "react-icons/bi";

export function Pricing17() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="mx-auto mb-8 max-w-lg text-center md:mb-10 lg:mb-12">
          <p className="mb-3 font-semibold md:mb-4">Costs</p>
          <h2 className="rb-5 mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
            What you'll pay
          </h2>
          <p className="md:text-md">
            Windscreen replacement prices vary by vehicle, glass type, and
            whether ADAS calibration is needed. Enter your registration number
            to see your exact cost before booking.
          </p>
        </div>
        <Tabs defaultValue="monthly">
          <TabsList className="mx-auto mb-12 w-fit">
            <TabsTrigger value="monthly">Standard</TabsTrigger>
            <TabsTrigger value="yearly">Heated</TabsTrigger>
          </TabsList>
          <TabsContent
            value="monthly"
            className="grid grid-cols-1 gap-8 data-[state=active]:animate-tabs md:grid-cols-2"
          >
            <div className="flex h-full flex-col justify-between border border-border-primary px-6 py-8 md:p-8">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="rb-4 mb-4 flex flex-col items-start justify-end">
                      <img
                        src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                        alt="Relume icon 1"
                        className="size-12"
                      />
                    </div>
                    <h5 className="mb-2 text-xl font-bold md:text-2xl">
                      Standard windscreen
                    </h5>
                    <p>Most common option</p>
                  </div>
                  <div className="text-right">
                    <h1 className="text-6xl font-bold md:text-9xl lg:text-10xl">
                      £150–£300
                    </h1>
                  </div>
                </div>
                <div className="my-8 h-px w-full shrink-0 bg-border" />
                <p>Includes</p>
                <div className="mb-8 mt-4 grid grid-cols-1 gap-x-6 gap-y-4 py-2 lg:grid-cols-2">
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Mobile technician to your address</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>OEM or equivalent glass</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Labour and fitting</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Sealant and adhesive</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Waste disposal</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Five-year warranty</p>
                  </div>
                </div>
              </div>
              <div>
                <Button title="Get price and book" className="w-full">
                  Get price and book
                </Button>
              </div>
            </div>
            <div className="flex h-full flex-col justify-between border border-border-primary px-6 py-8 md:p-8">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="rb-4 mb-4 flex flex-col items-start justify-end">
                      <img
                        src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                        alt="Relume icon 1"
                        className="size-12"
                      />
                    </div>
                    <h5 className="mb-2 text-xl font-bold md:text-2xl">
                      Heated windscreen
                    </h5>
                    <p>With heating elements</p>
                  </div>
                  <div className="text-right">
                    <h1 className="text-6xl font-bold md:text-9xl lg:text-10xl">
                      £220–£400
                    </h1>
                  </div>
                </div>
                <div className="my-8 h-px w-full shrink-0 bg-border" />
                <p>Includes</p>
                <div className="mb-8 mt-4 grid grid-cols-1 gap-x-6 gap-y-4 py-2 lg:grid-cols-2">
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Mobile technician to your address</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>OEM heated glass</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Labour and fitting</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Electrical connection</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Sealant and adhesive</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Waste disposal</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Five-year warranty</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>ADAS calibration available</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Additional cost applies</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Phone support included</p>
                  </div>
                </div>
              </div>
              <div>
                <Button title="Get price and book" className="w-full">
                  Get price and book
                </Button>
              </div>
            </div>
          </TabsContent>
          <TabsContent
            value="yearly"
            className="grid grid-cols-1 gap-8 data-[state=active]:animate-tabs md:grid-cols-2"
          >
            <div className="flex h-full flex-col justify-between border border-border-primary px-6 py-8 md:p-8">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="rb-4 mb-4 flex flex-col items-start justify-end">
                      <img
                        src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                        alt="Relume icon 1"
                        className="size-12"
                      />
                    </div>
                    <h5 className="mb-2 text-xl font-bold md:text-2xl">
                      Standard windscreen
                    </h5>
                    <p>Most common option</p>
                  </div>
                  <div className="text-right">
                    <h1 className="text-6xl font-bold md:text-9xl lg:text-10xl">
                      £150–£300
                    </h1>
                    <p className="mt-2 font-medium">Fixed price</p>
                  </div>
                </div>
                <div className="my-8 h-px w-full shrink-0 bg-border" />
                <p>Includes</p>
                <div className="mb-8 mt-4 grid grid-cols-1 gap-x-6 gap-y-4 py-2 lg:grid-cols-2">
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Mobile technician to your address</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>OEM or equivalent glass</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Labour and fitting</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Sealant and adhesive</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Waste disposal</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Five-year warranty</p>
                  </div>
                </div>
              </div>
              <div>
                <Button title="Get price and book" className="w-full">
                  Get price and book
                </Button>
              </div>
            </div>
            <div className="flex h-full flex-col justify-between border border-border-primary px-6 py-8 md:p-8">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="rb-4 mb-4 flex flex-col items-start justify-end">
                      <img
                        src="https://d22po4pjz3o32e.cloudfront.net/relume-icon.svg"
                        alt="Relume icon 1"
                        className="size-12"
                      />
                    </div>
                    <h5 className="mb-2 text-xl font-bold md:text-2xl">
                      Heated windscreen
                    </h5>
                    <p>With heating elements</p>
                  </div>
                  <div className="text-right">
                    <h1 className="text-6xl font-bold md:text-9xl lg:text-10xl">
                      £220–£400
                    </h1>
                    <p className="mt-2 font-medium">Fixed price</p>
                  </div>
                </div>
                <div className="my-8 h-px w-full shrink-0 bg-border" />
                <p>Includes</p>
                <div className="mb-8 mt-4 grid grid-cols-1 gap-x-6 gap-y-4 py-2 lg:grid-cols-2">
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Mobile technician to your address</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>OEM heated glass</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Labour and fitting</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Electrical connection</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Sealant and adhesive</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Waste disposal</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Five-year warranty</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>ADAS calibration available</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Additional cost applies</p>
                  </div>
                  <div className="flex self-start">
                    <div className="mr-4 flex-none self-start">
                      <BiCheck className="size-6" />
                    </div>
                    <p>Phone support included</p>
                  </div>
                </div>
              </div>
              <div>
                <Button title="Get price and book" className="w-full">
                  Get price and book
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}
